package se.umu.milo0047

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Main composable for the Thirty game app. Creates most of the UI and handles its logic.
 */
@Composable
fun ThirtyApp() {
    var diceValues by remember { mutableStateOf(listOf(1, 2, 3, 4, 5, 6)) }
    var diceHeld by remember { mutableStateOf(listOf(false, false, false, false, false, false)) }
    var rollsLeft by remember { mutableStateOf(3) }
    var rollButtonText by remember { mutableStateOf("Play") }
    var roundScore by remember { mutableStateOf(0) }
    var totalScore by remember { mutableStateOf(0) }
    var roundCount by remember { mutableStateOf(1) }
    var selectedScoringOption by remember { mutableStateOf("Select scoring option") }
    var usedScoringOptions by remember { mutableStateOf(setOf<String>()) }
    var isScoringMenuOpen by remember { mutableStateOf(false) }

    /**
     * Utility function to roll a dice.
     */
    fun rollDice(index: Int) {
        diceValues = diceValues.toMutableList().apply {
            this[index] = (1..6).random()
        }
    }

    /**
     * Utility function to reset a round.
     */
    fun resetRound(choice: String) {
        diceValues = listOf(1, 2, 3, 4, 5, 6)
        diceHeld = List(6) { false }
        rollsLeft = 3
        rollButtonText = "Play"
        roundCount++
        selectedScoringOption = "Select scoring option"
        isScoringMenuOpen = false
        usedScoringOptions = usedScoringOptions + choice
    }

    /**
     * Utility function to restart the game.
     */
    fun restartGame() {
        diceValues = listOf(1, 2, 3, 4, 5, 6)
        diceHeld = listOf(false, false, false, false, false, false)
        rollsLeft = 3
        rollButtonText = "Play"
        roundScore = 0
        totalScore = 0
        roundCount = 1
        selectedScoringOption = "Select scoring option"
        usedScoringOptions = emptySet()
        isScoringMenuOpen = false
    }

    /**
     * Utility function to calculate score. Not perfect!!! But works kind of well.
     */
    fun calculateScore(choice: String, diceValues: List<Int>): Int {
        return when (choice) {
            "Low" -> diceValues.filter { it <= 3 }.sum()
            else -> {
                val targetSum = choice.toInt()
                var score = 0

                val combinations = mutableListOf<List<Int>>()
                for (i in diceValues.indices) {
                    for (j in i until diceValues.size) {
                        combinations.add(diceValues.subList(i, j + 1))
                    }
                }

                for (combination in combinations) {
                    val sum = combination.sum()
                    if (sum == targetSum) {
                        score += sum
                    }
                }
                score
            }
        }
    }

    /**
     * Utility function to update the selected choice in the scoring menu
     * when a scoring option is selected. Then closes the menu. It is passed as
     * a parameter to the ScoringMenu composable for its onScoringOptionSelected event handling.
     */
    fun handleScoringOptionSelected(choice: String) {
        selectedScoringOption = choice
        isScoringMenuOpen = false
    }


    // Game UI
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        LazyVerticalGrid( // Six dice display in 2 by 3 grid
            columns = GridCells.Fixed(3)
        ) {
            itemsIndexed(diceValues) { index, value ->
                Dice(
                    value = value, held = diceHeld[index], onDiceClick = {
                        if (rollsLeft < 3) diceHeld =
                            diceHeld.toMutableList().apply { this[index] = !this[index] }
                    }, rollsLeft = rollsLeft
                )
            }

        }

        // Roll button
        Button(
            onClick = {
                diceValues.forEachIndexed { index, _ ->
                    if (rollsLeft <= 3 && !diceHeld[index]) {
                        rollDice(index)
                    }
                }
                rollsLeft--
                if (rollsLeft < 3) {
                    rollButtonText = "Roll ($rollsLeft)"
                }
            }, modifier = Modifier.fillMaxWidth(), enabled = rollsLeft > 0 && roundCount < 11
        ) {
            Text(text = rollButtonText, style = TextStyle(fontSize = 20.sp))
        }

        // Scoring menu button
        ScoringMenu(onScoringOptionSelected = { selectedChoice ->
            handleScoringOptionSelected(selectedChoice)
        },
            usedScoringOptions = usedScoringOptions,
            selectedScoringOption = selectedScoringOption,
            isScoringMenuOpen = isScoringMenuOpen,
            onMenuVisibilityChanged = { isVisible ->
                isScoringMenuOpen = isVisible
            })

        // Score button
        Button(
            onClick = {
                roundScore = calculateScore(selectedScoringOption, diceValues)
                totalScore += roundScore
                usedScoringOptions = usedScoringOptions + selectedScoringOption
                resetRound(selectedScoringOption)
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = selectedScoringOption != "Select scoring option" && rollsLeft == 0
        ) {
            Text(text = "Score", style = TextStyle(fontSize = 20.sp))
        }

        Text(
            text = "Round Score: $roundScore",
            style = TextStyle(fontSize = 20.sp),
            modifier = Modifier.padding(top = 8.dp)
        )

        Text(
            text = "Total Score: $totalScore",
            style = TextStyle(fontSize = 20.sp),
            modifier = Modifier.padding(top = 14.dp)
        )

        Text(
            text = "Round: $roundCount",
            style = TextStyle(fontSize = 20.sp),
            modifier = Modifier.padding(top = 8.dp)
        )

        // Shows the game result after 10 rounds.
        if (roundCount > 10) {
            GameResult(totalScore = totalScore, onRestart = {
                restartGame()
            })
        }
    }
}